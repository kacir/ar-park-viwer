create function st_dfullywithin(geom1 geometry, geom2 geometry, double precision)
  returns boolean
immutable
language sql
as $$
SELECT $1 OPERATOR(public.&&) public.ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public.ST_Expand($1,$3) AND public._ST_DFullyWithin(public.ST_ConvexHull($1), public.ST_ConvexHull($2), $3)
$$;

comment on function st_dfullywithin(geometry, geometry, double precision)
is 'args: g1, g2, distance - Returns true if all of the geometries are within the specified distance of one another';

alter function st_dfullywithin(geometry, geometry, double precision)
  owner to postgres;

